# RSS News Feed

Andriod app that allow you to display title and summaries from your favorite news website.

## Requirement

None

```bash
Make sure you have the latest Andriod Studio.
```

## Info

There are 7 Class in the file and to change the link, you can do that by going to FileIO class.

```bash
Note. The file are downloaded first before displaying on the screen.
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.
