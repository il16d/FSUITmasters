package edu.fsu.cs.cen4020.financ;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class Payment extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.ic_launcher);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        TextView monthlyPayment = (TextView)findViewById(R.id.txtMonthlyPayment);
        ImageView image = (ImageView)findViewById(R.id.imgYears);
        // Retrieving SharedPreferenes
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        float intYears = sharedPref.getFloat ("key1", 0); //the montlhy payment
        int intLoan = sharedPref.getInt("key2", 0); // the years
        float decInterest = sharedPref.getFloat("key3", 0); //principal
        float decMonthlyPayment;
        float month=12;

        // Calculate monthly payment    M = P [ i(1 + i)^n ] / [ (1 + i)^n – 1]
          decMonthlyPayment = ((intYears)*(intLoan*month))-decInterest;
        //decMonthlyPayment = (intLoan * (1 + (decInterest * intYears))) / (12 * intYears);
        // Format the monthly payment as currency
        DecimalFormat currency = new DecimalFormat("$###,###.##");
        // Display the monthly payment
        monthlyPayment.setText("Total Paid: " + currency.format(decMonthlyPayment));
        System.out.println("Whats the f%$#**n payment :" + decMonthlyPayment);
        /// Determine car loan payment period and display associated image
        if (intLoan == 10) { image.setImageResource(R.drawable.tens); }
        else if (intLoan == 20) {
            image.setImageResource(R.drawable.twents);
        }
        else if (intLoan == 30) {
            image.setImageResource(R.drawable.thirty);
        }
        else {monthlyPayment.setText("Enter 10, 20, or 30 years"); image.setImageResource(R.drawable.open);}
    }
}

